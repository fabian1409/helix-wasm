[
  (compound_statement)
  (declaration_list)
  (field_declaration_list)
  (enumerator_list)
  (parameter_list)
  (init_declarator)
  (expression_statement)
] @indent

[
  "case"
  "default"
  "}"
  "]"
  ")"
] @outdent

; Single statement after if/while/for/do without braces. Capture the body child
; naturally; on a typed newline the engine descends into it (no wrapper trick).
(if_statement
  consequence: (_) @indent
  (#not-kind-eq? @indent "compound_statement")
  (#set! "scope" "header"))
(while_statement
  body: (_) @indent
  (#not-kind-eq? @indent "compound_statement")
  (#set! "scope" "header"))
(do_statement
  body: (_) @indent
  (#not-kind-eq? @indent "compound_statement")
  (#set! "scope" "header"))
(for_statement
  body: (_) @indent
  (#not-kind-eq? @indent "compound_statement")
  (#set! "scope" "header"))

(parameter_list
  . (parameter_declaration) @anchor
  ) @align
(argument_list
  . (_) @anchor
  ) @align
; These are a bit opinionated since some people just indent binary/ternary expressions spanning multiple lines.
; Since they are only triggered when a newline is inserted into an already complete binary/ternary expression,
; this should happen rarely, so it is not a big deal either way.
; Additionally, adding these queries has the advantage of preventing such continuation lines from being used
; as the baseline when the `hybrid` indent heuristic is used (which is desirable since their indentation is so inconsistent).
(binary_expression
  ) @anchor @align
(conditional_expression
  "?" @anchor
  ) @align
