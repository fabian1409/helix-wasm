(statement) @indent

"}" @outdent
