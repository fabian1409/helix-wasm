; inherits: typescript
; inherits: jsx
